import React from 'react';

function Production() {
  return (
    <div>
      <h2>Production</h2>
    </div>
  );
}

export default Production;