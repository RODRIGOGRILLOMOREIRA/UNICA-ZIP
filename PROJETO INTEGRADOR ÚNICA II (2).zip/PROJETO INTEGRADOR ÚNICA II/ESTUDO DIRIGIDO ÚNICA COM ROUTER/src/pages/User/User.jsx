import React from 'react';

function User() {
  return (
    <div>
      <h2>User</h2>
    </div>
  );
}

export default User;
