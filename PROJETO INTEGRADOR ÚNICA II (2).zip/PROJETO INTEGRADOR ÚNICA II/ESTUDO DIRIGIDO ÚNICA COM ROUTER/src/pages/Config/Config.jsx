import React from 'react';

function Config() {
  return (
    <div>
      <h2>CONFIGURAÇÕES</h2>
    </div>
  );
}

export default Config;