import React from 'react';

function Materials() {
  return (
    <div>
      <h2>Materials</h2>
    </div>
  );
}

export default Materials;