import React from 'react';

function Reset() {
  return (
    <div>
      <h2>Reset</h2>
    </div>
  );
}

export default Reset;
