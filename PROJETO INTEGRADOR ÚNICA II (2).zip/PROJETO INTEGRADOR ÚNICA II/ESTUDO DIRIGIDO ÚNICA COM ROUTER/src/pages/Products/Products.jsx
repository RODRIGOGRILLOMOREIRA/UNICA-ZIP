import React from 'react';

function Products() {
  return (
    <div>
      <h2>Products</h2>
    </div>
  );
}

export default Products;