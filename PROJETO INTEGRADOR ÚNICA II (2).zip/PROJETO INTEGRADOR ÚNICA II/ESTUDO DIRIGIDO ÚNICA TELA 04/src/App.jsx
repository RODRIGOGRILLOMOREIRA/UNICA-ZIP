import "./App.css";
import Reset from "/src/Components/Reset/Reset";
function App() {
  return (
    <div className="App">
      <Reset/>
    </div>
  );
}

export default App;
