import "./App.css";
import Production from "/src/Components/Production/Production";
function App() {

  return (
   <div className="App">
    <Production/>
   </div>
  );
};

export default App;