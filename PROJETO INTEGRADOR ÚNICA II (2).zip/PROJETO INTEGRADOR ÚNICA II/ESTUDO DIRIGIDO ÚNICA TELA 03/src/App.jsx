import "./App.css";
import User from "/src/Components/User/User";
function App() {
  return (
    <div className="App">
      <User/>
    </div>
  );
}

export default App;
