import React from 'react'
import "./Home.css";
const Home = () => {
  return (
    <div className="container">
      <form>
        <h1>PROJETO INTEGRADOR ÚNICA</h1>
        <h2>SISTEMA DE GESTÃO DE LOGÍSTICA</h2>
        <h3>Seja bem vindo ao SLG !</h3>
        <button>
            ENTRAR
        </button>
      </form>
    </div>
  );
};

export default Home;

