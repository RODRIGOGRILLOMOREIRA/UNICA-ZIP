import "./App.css";
import Orders from "/src/Components/Orders/Orders";
function App() {

  return (
   <div className="App">
    <Orders/>
   </div>
  );
};

export default App;
